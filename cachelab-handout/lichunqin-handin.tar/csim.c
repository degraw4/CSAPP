#include "cachelab.h"

int main()
{
    printSummary(0, 0, 0);
    return 0;
}
